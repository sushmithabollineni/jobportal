from django.apps import AppConfig


class JobapplicationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jobapplication'
